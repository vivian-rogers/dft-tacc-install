
Nthreads=4

#mpirun -np $Nthreads pw.x < Fe.scf > scf.out
#mpirun -np $Nthreads pw.x < Fe.nscf > nscf.out
#mpirun -np $Nthreads wannier90.x -pp Fe
#mpirun -np $Nthreads pw2wannier90.x < Fe.pw2wan > pw2wan.out
#mpirun -np $Nthreads wannier90.x Fe
wannier90.x -pp Fe
pw2wannier90.x < Fe.pw2wan > pw2wan.out
wannier90.x Fe
postw90.x Fe

